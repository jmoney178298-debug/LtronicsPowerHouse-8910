# Keystone

Standalone app: landing + pricing, sign-up/sign-in, Stripe subscriptions, owner-only admin API, and the gated Keystone tool at `/app`.

## Deploy on Railway
1. Put this folder in its own GitHub repo (the files in this folder, with `package.json` at the root).
2. Railway: service `keystone-api` > Settings > Source: connect that repo. Start command is `npm start` (automatic).
3. Variables: see `.env.example`. The price IDs, owner email, APP_URL and DATABASE_URL are already set. You need `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET`.
4. Volume `/data` keeps your database. Do not remove it.

## Routes
- `/` landing, sign-in, account. `/app` the tool (owner or active subscribers).
- `/api/billing/*` checkout, portal, status. `/api/stripe/webhook` Stripe events.
- `/api/hot-leads*` subscribers. `/api/admin/*` owner only.

## Known limits
- Studio, Pipeline and Settings data still live in each user's browser. Hot leads and admin data are stored on the server.
- All plans unlock the same tool. Tier-specific limits are not enforced yet; `subscriptions.plan` stores the tier for when you add them.
- Not tested end to end. Run `npm install && npm start` locally once, sign up, and test a Stripe test-mode purchase before sending real customers.
